"""Matched replay: real neural outputs once, 3 seeded policies, identical budgets.

Scripted reactions exercise software only. No human fear/learning efficacy claim.
"""
from datetime import datetime,timezone
import json
from pathlib import Path
import sys
import time
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from brain.connectome import Connectome,ROOT
from brain.director import Budget,Readout,normalize,reaction

def main():
    brain=Connectome();trace=[]
    for k in range(60):
        telemetry={'x':4*np.sin(k*.25),'z':-4+5*np.cos(k*.14),'look_x':np.sin(k*.37),'look_z':-np.cos(k*.37),
                   'speed':1.6+1.5*np.sin(k*.17),'pause_seconds':max(0,np.cos(k*.3)),'retreat':max(0,1.5*np.sin(k*.4))}
        inputs=normalize(telemetry)
        trace.append({'utc':datetime.now(timezone.utc).isoformat(),'t':k*3.0,'inputs':inputs.tolist(),'neural':brain.step(inputs)})
    records=[];summary=[]
    for seed in [3,42,123]:
        for mode in ['random','fixed','learn']:
            layer=Readout(seed);budget=Budget();rewards=[];counts={a:0 for a in ['lights','steps','silhouette','wait']}
            for k,item in enumerate(trace):
                action,x,prob=layer.choose(mode,item['neural']['output']);requested=action
                if not budget.commit(action,item['t']):action='wait'
                counts[action]+=1;reward=0.
                if action!='wait':
                    # ponytail: scripted response, not a participant; replace with consented human sessions for efficacy claims.
                    response={'lights':.25,'steps':.55,'silhouette':.85}[action]*(.75+.25*np.sin(k*.33)**2)
                    reward=reaction({'speed':3.2,'retreat':0,'turn_rate':0},[{'speed':3.2*(1-response),'retreat':3.2*response,'turn_rate':180*response}])
                    rewards.append(reward)
                    if mode=='learn':layer.update(action,x,reward)
                records.append({**item,'seed':seed,'mode':mode,'requested':requested,'action':action,'reward':reward,'probabilities':prob,'updates':layer.updates})
            summary.append({'seed':seed,'mode':mode,'actions':counts,'events':len(rewards),'mean_scripted_response':float(np.mean(rewards)) if rewards else 0,
                            'updates':layer.updates,'weights':layer.weights.tolist()})
    (ROOT/'reports/experiment.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in records))
    result={'kind':'synthetic matched replay; not human fear evidence','graph':'full MaleCNS v1.0','seconds_per_session':180,
            'decision_seconds':3,'real_neural_decisions':60,'policy_runs':9,'budget':'5/60s, gap 8s, repeat 16s',
            'note':'Same measured neural trace replayed into all policies; only external readout learns. Reward response is scripted by action.', 'results':summary}
    (ROOT/'reports/experiment-summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

if __name__=='__main__':main()
