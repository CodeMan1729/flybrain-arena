"""Original deterministic quiet PCM assets; no downloaded samples."""
import math
from pathlib import Path
import random
import struct
import wave

root=Path(__file__).resolve().parents[1]/'game/audio'
root.mkdir(exist_ok=True)
rng=random.Random(42);rate=22050
for name,duration in [('steps',1.5),('hum',8.0)]:
    samples=[]
    for i in range(int(rate*duration)):
        t=i/rate
        if name=='steps':
            x=0
            for at in [.05,.55,1.03]:
                u=t-at
                if 0<=u<.22:
                    x+=(.5*math.sin(2*math.pi*76*u)+.15*rng.uniform(-1,1))*math.exp(-25*u)*min(1,u/.01)
            x*=.30
        else:
            x=.03*(math.sin(2*math.pi*48*t)+.3*math.sin(2*math.pi*96*t))*(.75+.25*math.cos(2*math.pi*t/8))
        samples.append(struct.pack('<h',int(max(-.18,min(.18,x))*32767)))
    with wave.open(str(root/(name+'.wav')),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(b''.join(samples))
