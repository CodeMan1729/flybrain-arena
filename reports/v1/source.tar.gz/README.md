# FLYFEAR

macOS ARM64 üzerinde yerel çalışan, birinci şahıs korku oyunu prototipi. İnsan anahtarı bulup koridordaki kilitli çıkışı açar. **Sinek bağlantı verisinden türetilen simülasyon oyuncuyu değil, odadaki olayları yönetir.**

Bu klasörde çalıştırılmış bir Godot oyunu, gerçek veri, ayrı Python simülasyonu, testler ve ölçüm raporları vardır. Ekran görüntüsü: [1080p oyun](reports/game-1080p.png). Ölçümler: [performans ve deney raporu](reports/PERFORMANCE.md).

## Başlatma

Bu makinede kurulum tamamlandı. Terminalde:

```sh
cd <project>
./run.sh
```

İlk kurulum/yeni kopya için `./setup.sh`; eksik kurulum varsa `./run.sh` bunu çağırır. Kurulum macOS ARM64 ve [uv](https://docs.astral.sh/uv/getting-started/installation/) gerektirir. Bu makinedeki uv: **0.9.15**. Python 3.12.12 uv ile kurulur; mevcut sistem Python'u değiştirilmez. Proje `.venv` kullanır. Godot yalnızca `tools/Godot.app` içine indirilir; `/Applications` değiştirilmez.

İlk indirme yaklaşık **1,11 GB veri + 162 MB Godot arşivi + Python paketleri**; kurulu klasör yaklaşık 1,9 GB. Yeniden kurulum mevcut ham veriyi silmez, SHA256 denetler. Tam grafiğin hazırlanması bu makinede yaklaşık 41 saniye sürdü. Kurulumda internet gerekir; **oyun sırasında ağ hedefi yalnızca `127.0.0.1`**. API hesabı, ücretli hizmet, CUDA, LLM veya bulut hesaplama gerekmez.

`run.sh` tek beyin ve tek Godot süreci başlatır. İkinci başlatmayı dosya kilidiyle engeller. Boş localhost portu ve her çalıştırmaya özel rastgele erişim anahtarı üretir; anahtar günlükte tutulmaz. Oyun kapanınca yalnızca başlattığı alt süreçleri temizler. Veri/model yüklenmezse nedenini yazıp durur; gerçek entegrasyon yerine gizli rastgele ağ çalıştırmaz.

## Oynanış ve Türkçe arayüz

1. Menüden modu seç ve **Başlat**'a bas. Başlangıç modu sabit bağlantı modelidir.
2. Masaya yaklaş, anahtara bak ve **E** ile al.
3. Koridora gir, sondaki kapıya yaklaş, **E** ile aç ve dışarı yürü.

| Tuş | İşlev |
|---|---|
| W A S D / fare | Hareket / bakış; gerçek `CharacterBody3D` çarpışmaları |
| F | El fenerini aç/kapat |
| E | Anahtar al / çıkış kapısını aç |
| TAB | Gerçek son sinir ölçümü, eylem, tepki vekili, FPS ve bellek paneli |
| ESC | Duraklat / devam; menüde çıkış |

Ayarlar: ses, efekt yoğunluğu, fare hassasiyeti, 2–5 saniye karar aralığı, tohum, tam ekran/pencere; öğrenilen karar parametrelerini kaydet/sıfırla. Mod, tohum ve karar aralığı yeni turda uygulanır. Varsayılan karar aralığı **3 saniye**. Yoğunluk 0 iken korku olayları uygulanmaz. Menüdeki sayılayıcılar klavyeyle de kullanılabilir; odak görünürdür.

Tek oda + kısa koridor; prosedürel duvar/floor malzemeleri, temel geometriden özgün mobilya, anahtar ve siluet. Harici ücretli varlık yok. `tools/generate_audio.py` iki özgün PCM sesi yeniden üretir. Ses örnekleri ±0,18 tam ölçekle sınırlandırılır; ayrıca ana ses, 3B ayak sesi ve ambiyans kazançları düşüktür. Bu yazılım kazancı sınırıdır, donanımdaki kulaklık/speaker ses basıncı ölçülmedi. Işık olayı odanın ana aydınlatmasını yumuşakça kısar; el feneri oyuncunun kontrolünde, koridorun acil ışıkları açık kalır.

## Mimari ve güvenli bekleme

```text
Godot: fizik / çizim / fare (bağımsız kare döngüsü)
  └─ 10 Hz hareket telemetrisi + 2–5 sn karar isteği
        localhost WebSocket, tek istemci, origin reddi + oturum anahtarı
  └─ Python: tek Connectome, SciPy CSR matris-vektör işlemleri (CPU)
        gerçek sinir çıktısı → rastgele / sabit / öğrenen karar katmanı
        bütçe → olay önerisi → Godot uygulama onayı
        2 sn hareket penceresi → tepki vekili → yalnızca dış katman güncellemesi
```

Godot WebSocket'i her karede `poll()` ile işler; simülasyon için bekleyen çağrı yapmaz. Python sayısal adımı `asyncio.to_thread` içinde hesaplar, tek model durumu korunur. Sunucu bir bağlantı dışında tüm istemcileri reddeder. 8 KiB mesaj sınırı, sınırlı kuyruk, sayısal giriş doğrulaması vardır.

**1,5 saniye** içinde gelmeyen yanıt atılır. Eski istek kimliği, duraklatılmış oyun veya kopmuş bağlantının yanıtı uygulanmaz. Varsayılan eylem `wait`tir. Bağlantı 3 saniyede bir yeniden denenir. Yeniden bağlanınca sinir durumu sıfırlanır; öğrenen mod kayıtlı dış katmanı yükler. Oyun tarafındaki olay bütçesi bağlantı kopmasıyla sıfırlanmaz. Duraklatma aktif efektleri durdurur ve eksik tepki penceresini iptal eder.

**Her üç mod için aynı kısıtlar:** 60 saniyelik kayan pencerede en fazla 5 korku olayı; olaylar arası en az 8 saniye; aynı olay için en az 16 saniye. `wait` bütçe tüketmez. Sunucu bütçeyi yalnızca uygulanmış olay onayından sonra işler; Godot aynı kısıtları ayrıca kontrol eder. Oyun duraklatılırsa yerel oyun saati durur; yerel kontrol sunucuya göre daha kısıtlayıcı olabilir.

## Gerçek verinin kapsamı

**MaleCNS v1.0**, erişim ve lisans kontrolü: **10 Eylül 2026**. Kaynak: [MaleCNS resmi indirme sayfası](https://male-cns.janelia.org/download/). Veri [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) kapsamında. Katkı: MaleCNS işbirliği, FlyEM / HHMI Janelia, Cambridge Zoology, MRC LMB ve Google Research; yayının tüm yazarları ve veri katkıcıları. [Özgün yayın](https://doi.org/10.1016/j.cell.2026.08.015), [Google Research açıklaması](https://research.google/blog/a-connectomics-milestone-mapping-the-complete-male-fruit-fly-brain/).

Yerel model **166.700 tanımlı nöron**, **25.582.938 yönlü kenar**, **124.177.617 sinaptik temas** içerir. Kenar ve sinaps aynı şey değildir: bir kenarın ağırlığı temas sayısıdır. Beyin ve ventral sinir kordonu birlikte kapsanır. Ek ağırlık eşiği uygulanmaz; kendine bağlantılar korunur.

Ham dosya 151.856.684 segment bağlantısı içerir. `superclass` atanmış, `status != Glia` kayıtlar nöron olarak tutulur; bu kayıtların dışındaki segmentlere giden/gelen 126.273.746 kenar modele girmez. Bu, veri temizliği ve nöron tanımıdır; RAM kazanmak için seçilmiş devre alt ağı değildir. **Alt ağ küçültmesi yapılmadı.** Ekrandaki TAM GRAF bu tanımlı nöron grafiğini ifade eder; tüm ham segmentleri veya canlı bir beynin her bilinmeyen özelliğini ifade etmez.

### Doğrudan indirme ve yeniden hazırlama

`research/source.lock.json`, DOOMFLY'nin aşağıda sabitlenen sürümündeki URL, bayt ve SHA256 kayıtlarını içerir. İndirici resmi kaynağa gider, kısmi dosyayı `.partial` tutar, hash doğrulamadan asıl ada taşımaz. Kısmi bozuk indirme otomatik olarak başka veriyle değiştirilmez; hatalı `.partial` dosyasını inceleyip kaldırdıktan sonra tekrar denenebilir.

| Dosya | Bayt | Resmi URL |
|---|---:|---|
| `annotations.feather` | 14.483.314 | [Nöron açıklamaları](https://storage.googleapis.com/flyem-male-cns/v1.0/connectome-data/flat-connectome/body-annotations-male-cns-v1.0-minconf-0.5.feather) |
| `neurotransmitters.feather` | 43.282.834 | [Nörotransmiter tahminleri](https://storage.googleapis.com/flyem-male-cns/v1.0/connectome-data/flat-connectome/body-neurotransmitters-male-cns-v1.0.feather) |
| `edges.feather` | 1.051.241.946 | [Yönlü bağlantı ağırlıkları](https://storage.googleapis.com/flyem-male-cns/v1.0/connectome-data/flat-connectome/connectome-weights-male-cns-v1.0-minconf-0.5.feather) |

```sh
.venv/bin/python tools/download_data.py
.venv/bin/python -m brain.connectome prepare
.venv/bin/python -m brain.connectome benchmark
```

Hazırlama, ham dosyaları yeniden SHA256 doğrular; Feather verisini parçalar halinde okur. `counts.npz` özgün temas ağırlıklarını, `weights.npz` dönüştürülmüş sayısal matrisi, `ids.npy` kesin tamsayı biyolojik kimlikleri tutar. `data/manifest.json` kayıpları ve kapsamı, `data/mapping.json` her giriş/çıkışın tam biyolojik ID listesini içerir. Kimlikler JSON'da ondalık metin olarak saklanır; kayan noktadan geçirilmez.

## Sayısal model: ne gerçek, ne tasarım?

**Gerçek:** hangi nöronun hangisine bağlandığı, temas sayıları, hücre tipi açıklamaları, kaynak nörotransmiter tahminleri. **Mühendislik tasarımı:** oyun telemetrisinin nöronlara atanması, dinamik denklem, kazanç/sızıntı, çıktı hücrelerinin olaylara atanması, ödül ve karar katmanı.

Bu prototip DOOMFLY LIF çekirdeğini veya Shiu modelini çalıştırmaz. Gerçek bağlantılar üzerinde küçük, denetlenebilir **işaretli etkinlik sapması modeli** çalıştırır. Rakamlar ateşleme frekansı/Hz ya da biyolojik ölçüm değildir. Uygulama içinde gerçekten hesaplanan sayısal nöron etkinliği gösterilir; dekoratif beyin animasyonu kullanılmaz.

`C[post, pre]` temas sayısı; `s(pre)` ACh için +1, GABA/glutamat/histamin için −1; belirsiz ve dopamin/serotonin/oktopamin için 0. Reseptör bağlamı bilinmediği için bu işaretler basitleştirmedir. **3.718 nöronun çıkış işareti 0**; modülasyon dinamiği bu sürümde modellenmez. Topolojik kenarlar saklanır, etkin işaretli kenar sayısı **24.559.135** olur. Bu sınırlama azaltılmış nöron alt ağıyla karıştırılmamalıdır.

```text
W[j,i] = C[j,i] * s(i) / max(1, sum_i C[j,i])
a ← a + 0.35 * (tanh(1.5 * W @ a + drive) - a)
```

Her karar için 24 güncelleme yapılır; `a` sonraki karara taşınır. Yeni turda sıfırlanır. Biyolojik zaman karşılığı kalibre edilmemiştir. Modelde rastgele kenar, rastgele iç nöron gürültüsü veya sinaptik öğrenme yoktur. Tüm kayıtlı düğümler hesaplanır; belirsiz işaretler ve izole düğümler sessiz kalabilir.

### Giriş ve çıkış eşlemesi

`type == R1-R6` olan **3.377** nöron biyolojik ID'ye göre sıralanıp sekiz ardışık gruba bölünür. İlk grup 423, diğerleri 422 hücre. Her grubun tam ID listesi `data/mapping.json → input_body_ids` altındadır. Sıralama uzamsal retina eşlemesi veya doğal duyusal semantik iddiası taşımaz.

| Giriş | Normalizasyon (sonuç −1…1'e kırpılır) |
|---|---|
| x | `x / 6` |
| z | `(z + 5) / 11` |
| look_x, look_z, look_y | Kameranın birim ileri vektörü bileşenleri |
| speed | `2 * yatay_hız / 3.2 - 1` |
| pause | `2 * duraksama_saniyesi / 3 - 1` |
| retreat | `2 * max(0, -hız_vektörü · bakış) / 3.2 - 1` |

Grup sürüşü `0.2 + 0.8 * (girdi + 1) / 2`; diğer hücrelerde doğrudan sürüş 0. Giriş→bağlantılar→çıktı akışı testte gerçek grafikte görülür; aynı girdide kenarlar sıfırlanınca çıkış grupları sessiz kalır.

| Ölçülen grubun ortalama etkinliği | Hücre sayısı | Atanan olay |
|---|---:|---|
| L1 | 1.776 | Oda ışığını kıs/söndür |
| L2 | 1.779 | Oyuncunun arkasına konumlandırılan 3B ayak sesi |
| L3 | 1.772 | Görüş kenarında kısa siluet |
| Mi1 | 1.773 | Bekle |

Bu hücreler doğal “korkutma nöronları” değildir. Olay anlamları bilinçli arayüz tasarımıdır. Işıklar ve sesler bütçe sınırından geçtikten sonra uygulanır.

**Adaptör değişimi:** `brain/connectome.py` içindeki `Connectome` sınıfının sözleşmesi `info`, `reset()` ve `step(normalized[8]) → {output[4], mean_abs, active_neurons, peak_abs, latency_ms, rss_mb}`. `server.py` yalnızca bu sözleşmeye dayanır. Farklı veri/model uygulanırken manifest kapsamını, kimlik eşlemesini ve öğrenme kaydının model sürümünü değiştirin; geçmiş parametreleri sıfırlayın. Kullanılmayan eklenti sistemi veya rastgele ağ adaptörü eklenmedi.

## Üç deney modu ve öğrenmenin sınırı

- **Rastgele kontrol:** dört eylem eşit olasılıklı. Gerçek model yine hesaplanır ve günlüğe yazılır; eylemde kullanılmaz. Bu mod arayüzde rastgele olarak etiketlidir.
- **Sabit model:** dört sinir çıktısı `max(0.05, max(abs(output)))` ile ölçeklenir; sabit 1,2 katsayılı readout üzerinden `0.9 * softmax + 0.1/4` dağılımıyla seçilir. Sinir ve karar ağırlıkları sabittir; seçimin tohumlu örneklenmesi deterministik ağırlıklarla karıştırılmamalıdır.
- **Beyin + öğrenen karar katmanı:** aynı başlangıç readout'u; dört sinir çıktısı ve bir bias üzerinde 4×5 ağırlık. Uygulanmış olaydan sonra sigmoid tahmin hatasıyla 0,15 adımda güncellenir; ağırlıklar ±3'e sınırlıdır. Yalnızca bu **dış karar katmanı** öğrenir. Bağlantı haritası ve sinir dinamiği değişmez.

Tepki vekili, olayın gerçekten uygulandığı andaki hareketi temel alır; yaklaşık 10 Hz örneklenmiş 2 saniyelik pencerede geri çekilme artışı, mutlak dönme hızı artışı ve hareketliyken durma miktarının tepe değerlerini kullanır. Her bileşen 0…1'e kırpılır:

```text
tepki = 0.40 * geri_çekilme + 0.35 * dönme + 0.25 * durma
```

Ölçekler: 3,2 m/s ve 180 derece/s. Zaten duran oyuncu sırf hareketsiz kaldığı için puan üretmez. Bu vekil isteyerek hareket etme, keşif veya kontrol hatasıyla da artabilir. **Korku, duygu ya da klinik ölçüm değildir.** Beklemeye, reddedilen olaya, yinelenen/gecikmiş onaya veya iptal edilen pencereye öğrenme uygulanmaz. Kamera, mikrofon ve nabız kullanılmaz.

`Ayarlar → Kaydet / Sıfırla`; öğrenen tur bittiğinde ve bağlantı temiz kapandığında otomatik kayıt. Normal kayıt `logs/sessions/learning.json`; testler `logs/validation/learning.json` kullanır. Parametre yazımı geçici dosya + atomik yeniden adlandırmadır. Bozuk kayıt sessizce sıfırlanmaz; hata gösterilir, kullanıcı sıfırlama düğmesini kullanabilir. Ses/yoğunluk gibi diğer ayarlar yalnızca açık uygulama süresince tutulur.

### Karşılaştırmayı yeniden çalıştır

Oyun kapalıyken:

```sh
.venv/bin/python tools/experiment.py
```

Tam grafikten 60 gerçek karar çıktısı bir kez ölçülür. Aynı çıktı dizisi üç mod × üç tohum (3, 42, 123) için tekrar oynatılır. Her oturum 180 sanal saniye, 3 saniye karar aralığı ve aynı bütçeyi kullanır. Sentetik tepkiler yalnızca katmanı ve deneyi sınar. Dokuz sonuç ve her adımın girdisi/çıktısı/eylemi/ödülü `reports/experiment-summary.json` ve `reports/experiment.jsonl` içindedir. Öğrenen katmanın sabit modeli geçtiği sonucu çıkmadı; ayrıntılı tablo performans raporundadır.

Bu, insan katılımcılı çalışma değildir. İnsan karşılaştırmasında aynı süre/yoğunluk/bütçe, karşı dengelenmiş mod sırası, yeni tohumlar ve tur başı parametre sıfırlama gerekir. Şu anki sentetik sonuçlardan gerçek korkutma başarısı veya genellenebilir öğrenme çıkarılamaz.

## Yerel kayıt ve ölçüm

`logs/sessions/<oturum>.jsonl`: UTC zaman damgası, monotonic zaman, oturum, tohum, mod, ham/normalize girdiler, gerçek dört sinir çıktısı, ortalama/tepe etkinlik, etkin nöron sayısı, önerilen/uygulanan eylem, seçim olasılıkları, gecikme, beyin RSS, onay ve tepki örnekleri/ödülü. Pause/reconnect/save/reset olayları da kaydedilir. Öğrenme sayacı görünürdür. Konumlar gerçek dünya konumu değil oyun koordinatıdır. Kayıtlar sunucuya gönderilmez.

TAB panelindeki bellek: beyin **RSS**, oyun ise Godot **heap** sayacıdır; aynı ölçü değildir. Başlatıcı her 0,5 saniyede iki sürecin gerçek RSS değerini de `*-memory.json` içine kaydeder. Kare süreleri testte gerçek `Time.get_ticks_usec()` aralıklarıdır; ilk 2 saniye dışarıda bırakılır. 1080p testi gerçek çizimle ayrı yapılır; headless FPS değeri grafik performansı olarak kullanılmaz.

## Testler

```sh
./test.sh                           # 8 birim/entegrasyon testi + baştan sona headless oyun
./run.sh --benchmark                # görünür 1920×1080, sabit model, ölçümlü tam tur
./run.sh --benchmark --mode=learn   # görünür 1920×1080, öğrenen katman, tam tur
```

Testler `unittest` ve Godot'un kendisini kullanır; ayrı test çerçevesi yok. Kapsam: hash kontrollü gerçek veri hazırlama, nöron/kenar/temas sayıları, tam biyolojik ID eşlemesi, gerçek girdi→sinir çıktısı→eylem, bağlantı ablasyonu, sayısal giriş doğrulama, ödülün sınırı ve başlangıç hareketi, tohum tekrarı, parametre kayıt/sıfırlama/bozuk dosya, aynı bütçe, yetkisiz WebSocket/origin reddi, uygulanmış olay onayı ve yinelenen onay, sunucuyu sonlandırma, yeniden bağlantı, 1,85 saniye geciken yanıtı atan **üretim Godot istemcisi**, kesintide çalışan kare döngüsü.

Oyun turu gerçek fizik üzerinden duvara yürür, kilitli kapıyı dener, masaya döner, anahtarı alır, her efekti ve cooldown'u sınar, duraklatır, socket'i koparır/yeniden bağlar ve anahtarla çıkışı açıp zafer durumuna girer. Efekt zorlamaları yalnızca `--smoke` / `--benchmark` test akışında yapılır ve ödül almamak için geçersiz onay kimliği kullanır. Otomatik rota insan oynanış testi yerine geçmez; temel oyun akışını doğrular.

## Doğrulanan özgün kaynaklar / sürümler

| Kaynak | Sabit sürüm / sonuç |
|---|---|
| [DOOMFLY](https://github.com/nftechie/doomfly/tree/71ecf53d78eaffaf1a57ed7b0ccf5d458abc9f33) | `71ecf53d78eaffaf1a57ed7b0ccf5d458abc9f33`, özgün kod MIT. MaleCNS veri kaydı ve kaynak hash'leri kullanıldı; çekirdek kodu oyuna alınmadı. |
| [DOOMFLY canlı deney protokolü](https://github.com/nftechie/doomfly/blob/71ecf53d78eaffaf1a57ed7b0ccf5d458abc9f33/docs/doom-live-training.md) | Kaynak, deneysel plastisiteyi başarılı öğrenme kanıtından ayırır. README v6 adayının görsel, koşullama ve hayatta kalma doğrulama kapılarını geçemediğini bildirir. |
| [DOOMFLY C++ derleme](https://github.com/nftechie/doomfly/blob/71ecf53d78eaffaf1a57ed7b0ccf5d458abc9f33/doom/build_kernel.py) | Darwin için `.dylib` yolu var. Bu kod düzeyinde macOS desteğidir; DOOMFLY'nin tüm ViZDoom yığını burada kurulup test edilmedi. FLYFEAR kendi daha küçük bağımlılık setiyle ARM64 üzerinde test edildi. |
| [Shiu ve ark. özgün model](https://github.com/philshiu/Drosophila_brain_model/tree/91bdd1e7dcf193f3e7ca5a8933497fcef63b7960) | `91bdd1e7dcf193f3e7ca5a8933497fcef63b7960`, MIT; README Mac/Windows/Unix ve Brian2/C++ yolunu belirtir. Kaynak v630 varsayılanını ve v783 seçeneğini ayırır. FLYFEAR bu modelin yeniden üretimi değildir. |
| [Shiu ve ark., Nature 2024](https://doi.org/10.1038/s41586-024-07763-9) | Gerçek bağlantıya dayalı hesaplamalı sensörimotor araştırma; bir oyunda insanı korkutmayı veya kendiliğinden öğrenmeyi doğrulamaz. |
| [Godot 4.5.2 stable](https://godotengine.org/download/archive/4.5.2-stable/) | `6ce3de25aa58466e14ef354703ba8d9791a417da`; resmi universal macOS ikilisi, SHA512 doğrulandı. ARM64 ve Compatibility renderer kullanıldı. |
| [Godot WebSocket belgeleri](https://docs.godotengine.org/en/4.5/tutorials/networking/websocket.html) | Yerel istemci `WebSocketPeer` ve sürekli poll. |
| [SciPy CSR 1.15.3](https://docs.scipy.org/doc/scipy-1.15.3/reference/generated/scipy.sparse.csr_matrix.html) | CPU sparse matris-vektör çarpımı. |
| [websockets 15.0.1](https://websockets.readthedocs.io/en/15.0.1/reference/asyncio/server.html) | Async localhost sunucusu, origin/mesaj sınırları. |

Python **3.12.12**; NumPy **2.2.6**, SciPy **1.15.3**, PyArrow **20.0.0**, websockets **15.0.1**, psutil **7.0.0**. Kesin paket sürümleri `requirements.txt` içindedir. Godot SHA512 listesi `research/godot-SHA512-SUMS.txt`; DOOMFLY/Shiu lisans ve kaynak inceleme kopyaları `research/` altındadır. Araştırma dosyaları çalıştırılan koddan ayrıdır.

## Sınırlar ve lisans

Bu prototipte alt ağ modu gerekmedi ve eklenmedi; tam grafiğin ölçümü hedef aralığa sığdı. Kalibre LIF dinamiği, reseptör bazlı nöromodülasyon, bilimsel biyolojik doğrulama, insan korku çalışması, uzun süreli dayanıklılık testi, başka Mac modelleri ve dışa aktarılmış/imzalanmış `.app` dağıtımı yapılmadı. Kaynak Godot projesi ve tek komutlu yerel başlatıcı teslim edilir. 1080p/60 FPS hedefi ölçülen bu kısa senaryoda karşılandı; farklı ekran, güç modu, termal yük veya uzun oturum için garanti verilmez.

Özgün FLYFEAR kodu ve prosedürel varlıkları [MIT](LICENSE). MaleCNS verisi ve dönüştürülmüş bağlantı/eşleme çıktıları CC BY 4.0 olarak kaynak atfını korur; FLYFEAR'ın yaptığı filtreleme/normalizasyon/eşleme değişiklikleri yukarıda açıklanmıştır. [Üçüncü taraf bildirimleri](THIRD_PARTY.md). DOOMFLY, veri yazarları veya Godot tarafından onaylanmış bir proje değildir.
