"""Shared event budget, bounded movement proxy, and external reward readout."""
from collections import deque
import json
import math
from pathlib import Path
import numpy as np
from .connectome import ACTIONS, FEATURES

def normalize(t):
    def number(key, default=0):
        value = t.get(key, default)
        if isinstance(value, bool) or not isinstance(value, (float,int)) or not math.isfinite(value):
            raise ValueError(f'Invalid telemetry: {key}')
        return value
    # World bounds: room x [-6,6], z [-6,6]; corridor z [-16,-6].
    values = [number('x')/6, (number('z')+5)/11, number('look_x'), number('look_z'), number('look_y'),
              2*number('speed')/3.2-1, 2*number('pause_seconds')/3-1, 2*number('retreat')/3.2-1]
    return np.clip(values,-1,1).astype(np.float32)

def reaction(baseline, samples):
    """Movement proxy [0,1]; compare pre-event movement with a 2 s window."""
    if not samples:
        return 0.0
    retreat = max(max(0, s['retreat']-baseline['retreat'])/3.2 for s in samples)
    turn = max(max(0, abs(s['turn_rate'])-abs(baseline['turn_rate']))/180 for s in samples)
    stop = max(max(0, baseline['speed']-s['speed'])/3.2 for s in samples) if baseline['speed'] > .4 else 0
    return float(np.clip(.4*min(retreat,1)+.35*min(turn,1)+.25*min(stop,1),0,1))

def movement(t):
    normalize(t)
    result = {k: float(t.get(k,0)) for k in ('speed','retreat','turn_rate')}
    if not all(math.isfinite(v) and abs(v) < 10000 for v in result.values()):
        raise ValueError('Invalid movement sample')
    return result

class Budget:
    LIMIT = 5
    GAP = 8.0
    REPEAT = 16.0
    def __init__(self):
        self.events = deque()
    def allowed(self, action, now):
        while self.events and self.events[0][0] <= now-60:
            self.events.popleft()
        return action == 'wait' or (len(self.events) < self.LIMIT and
            (not self.events or now-self.events[-1][0] >= self.GAP) and
            all(a != action or now-t >= self.REPEAT for t,a in self.events))
    def commit(self, action, now):
        if not self.allowed(action,now):
            return False
        if action != 'wait': self.events.append((now,action))
        return True

class Readout:
    def __init__(self, seed=42, path=None):
        self.rng = np.random.default_rng(seed)
        self.path = Path(path) if path else None
        self.reset()
    def reset(self):
        self.weights = np.column_stack((1.2*np.eye(4), np.zeros(4)))
        self.updates = 0
    def features(self, output):
        out = np.asarray(output, dtype=float)
        if out.shape != (4,) or not np.isfinite(out).all(): raise ValueError('Invalid neural output')
        return np.append(out / max(.05, float(np.max(np.abs(out)))), 1)
    def choose(self, mode, output):
        x = self.features(output)
        if mode == 'random': p=np.ones(4)/4
        else:
            w = self.weights if mode == 'learn' else np.column_stack((1.2*np.eye(4),np.zeros(4)))
            score = w@x; p=np.exp(score-score.max()); p=.9*p/p.sum()+.1/4
        return ACTIONS[int(self.rng.choice(4,p=p))], x, p.tolist()
    def update(self, action, x, reward):
        if action not in ACTIONS or not math.isfinite(reward) or not 0 <= reward <= 1: raise ValueError('Invalid reward')
        i=ACTIONS.index(action)
        prediction=1/(1+np.exp(-np.clip(self.weights[i]@x,-20,20)))
        self.weights[i] = np.clip(self.weights[i]+.15*(reward-prediction)*x,-3,3)
        self.updates += 1
    def save(self):
        if not self.path: return
        self.path.parent.mkdir(parents=True,exist_ok=True)
        tmp=self.path.with_suffix('.tmp')
        tmp.write_text(json.dumps({'schema':1,'model':'malecns-rate-v1','weights':self.weights.tolist(),'updates':self.updates}))
        tmp.replace(self.path)
    def load(self):
        if not self.path or not self.path.exists(): return
        data=json.loads(self.path.read_text()); w=np.asarray(data['weights'],dtype=float)
        if data.get('schema')!=1 or data.get('model')!='malecns-rate-v1' or w.shape!=(4,5) or not np.isfinite(w).all() or np.max(np.abs(w))>3:
            raise ValueError('Invalid saved learning parameters')
        self.weights=w; self.updates=int(data['updates'])
