"""One CPU connectome process; localhost-only authenticated WebSocket endpoint."""
import argparse
import asyncio
from datetime import datetime, timezone
import json
import os
import signal
from pathlib import Path
import time
import uuid

from websockets.asyncio.server import serve
from websockets.exceptions import ConnectionClosed
from .connectome import Connectome, ROOT
from .director import Budget, Readout, normalize, movement, reaction

async def run(port, token, log_dir):
    brain = await asyncio.to_thread(Connectome)
    stopped=asyncio.Event()
    asyncio.get_running_loop().add_signal_handler(signal.SIGTERM,stopped.set)
    busy = False
    log_dir.mkdir(parents=True,exist_ok=True)
    async def handler(ws):
        nonlocal busy
        if ws.request.path != '/'+token or busy:
            await ws.close(1008,'Unauthorized or simulation in use'); return
        busy=True
        session=uuid.uuid4().hex
        log=(log_dir/f'{session}.jsonl').open('a',buffering=1)
        seed=42; mode='fixed'; interval=3.; last_decision=-1e10
        budget=Budget(); layer=Readout(seed,log_dir/'learning.json')
        pending=None; window=None; enabled=False
        def record(kind, **data):
            log.write(json.dumps({'type':kind,'utc':datetime.now(timezone.utc).isoformat(),'monotonic':time.monotonic(),
                                  'session':session,'seed':seed,'mode':mode,**data},allow_nan=False)+'\n')
        async def send(data):
            await ws.send(json.dumps(data,allow_nan=False))
        try:
            brain.reset()
            await send({'type':'hello','info':brain.info,'protocol':1})
            record('connected',dataset=brain.info)
            async for raw in ws:
                try:
                    msg=json.loads(raw)
                    if not isinstance(msg,dict): raise ValueError('Expected object')
                    now=time.monotonic(); kind=msg.get('type')
                    if kind=='start':
                        if msg.get('mode') not in ('random','fixed','learn'): raise ValueError('Unknown mode')
                        if mode=='learn': layer.save()
                        seed=int(msg.get('seed',42))
                        if not 0<=seed<2**32: raise ValueError('Seed range')
                        mode=msg['mode']; interval=float(msg.get('interval',3))
                        if not 2<=interval<=5: raise ValueError('Interval range 2..5 s')
                        layer=Readout(seed,log_dir/'learning.json')
                        if mode=='learn': layer.load()
                        brain.reset(); budget=Budget(); pending=window=None; enabled=True; last_decision=now
                        record('start',interval=interval,updates=layer.updates)
                        await send({'type':'started','session':session,'updates':layer.updates})
                    elif kind=='pause':
                        enabled=False; pending=window=None; record('paused')
                    elif kind=='resume':
                        enabled=True; last_decision=now; record('resumed')
                    elif kind in ('save','reset'):
                        if kind=='reset': layer.reset()
                        layer.save(); record(kind,updates=layer.updates)
                        await send({'type':'parameters','operation':kind,'updates':layer.updates})
                    elif kind=='applied':
                        if pending and msg.get('id')==pending['id'] and now-pending['time']<1.5:
                            accepted=msg.get('accepted') is True
                            baseline=movement(msg.get('telemetry',{}))
                            if accepted and budget.commit(pending['action'],now) and pending['action']!='wait':
                                window={**pending,'time':now,'samples':[], 'baseline':baseline}
                            record('applied',id=pending['id'],action=pending['action'],accepted=accepted)
                            pending=None
                    elif kind in ('telemetry','decision'):
                        t=msg.get('telemetry',{}); values=normalize(t); sample=movement(t)
                        if not enabled: continue
                        if window:
                            window['samples'].append(sample)
                            if now-window['time']>=2:
                                reward=reaction(window['baseline'],window['samples'])
                                if mode=='learn': layer.update(window['action'],window['features'],reward)
                                record('reward',id=window['id'],action=window['action'],reward=reward,
                                       baseline=window['baseline'],samples=window['samples'],updates=layer.updates)
                                await send({'type':'reward','reward':reward,'updates':layer.updates})
                                window=None
                        if kind!='decision': continue
                        seq=msg.get('id')
                        if type(seq) is not int or seq<0: raise ValueError('Invalid request id')
                        if now-last_decision<interval-.05 or window or (pending and now-pending['time']<1.5):
                            await send({'type':'decision','id':seq,'action':'wait','reason':'cooldown'}); continue
                        last_decision=now
                        result=await asyncio.to_thread(brain.step,values)
                        action,x,probabilities=layer.choose(mode,result['output'])
                        requested=action
                        if not budget.allowed(action,time.monotonic()): action='wait'
                        pending={'id':seq,'time':time.monotonic(),'action':action,'features':x,'baseline':sample}
                        record('decision',id=seq,inputs=values.tolist(),raw_inputs=t,neural=result,action=action,
                               requested=requested,probabilities=probabilities,updates=layer.updates)
                        await send({'type':'decision','id':seq,'action':action,'neural':result,'budget_used':len(budget.events),
                                    'updates':layer.updates,'reason':'budget' if action!=requested else 'selected'})
                    else: raise ValueError('Unknown message type')
                except (ValueError,KeyError,TypeError,OverflowError) as exc:
                    record('invalid',error=str(exc)); await send({'type':'error','message':str(exc),'action':'wait'})
        except ConnectionClosed:
            pass
        finally:
            try:
                if mode=='learn': layer.save()
                record('disconnected')
            finally:
                log.close(); busy=False
    async with serve(handler,'127.0.0.1',port,origins=[None],max_size=8192,max_queue=4,ping_interval=10,ping_timeout=10):
        print(json.dumps({'ready':True,'port':port,'neurons':brain.info['neurons']}),flush=True)
        await stopped.wait()

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--port',type=int,default=8765);p.add_argument('--logs',type=Path,default=ROOT/'logs')
    args=p.parse_args(); token=os.environ.get('FLYFEAR_TOKEN','')
    if len(token)<16: raise SystemExit('FLYFEAR_TOKEN must contain >=16 characters')
    try: asyncio.run(run(args.port,token,args.logs))
    except KeyboardInterrupt: pass
