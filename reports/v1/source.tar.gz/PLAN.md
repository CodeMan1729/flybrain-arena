# FLYFEAR tamamlanan uygulama adımları

- [x] Boş klasör ve ARM64 ortamı; kaynak/lisans sürümleri doğrulandı.
- [x] MaleCNS v1.0 SHA256 kontrollü indirildi; tam grafiğin RAM/gecikmesi ölçüldü.
- [x] Tek beyin süreci, localhost WebSocket, üç mod ve gerçek etkinlik.
- [x] Godot oda/koridor, anahtar/çıkış, Türkçe menü ve sınırlı olaylar.
- [x] 8 test, 27 headless / 27 sabit / 23 öğrenen görünür oyun kontrolü, kesinti/gecikme ve görünür 1080p bitiriş.
- [x] Kurulum/başlatma, kaynaklar, model varsayımları ve performans/deney raporu.

Kanıtlar ve doğrulanmayan kapsam: reports/PERFORMANCE.md ve README.md.
