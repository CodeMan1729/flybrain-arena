"""Real local worker integration: auth, neural response, ACK/reward, reset, restart."""
import asyncio
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import unittest

from websockets.asyncio.client import connect
from websockets.exceptions import ConnectionClosed, InvalidStatus
from brain.connectome import ROOT

class SocketTests(unittest.IsolatedAsyncioTestCase):
    async def test_real_worker(self):
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0)); port=sock.getsockname()[1]
        token='integration-test-token-42'
        with tempfile.TemporaryDirectory() as tmp:
            output=open(Path(tmp)/'server.log','w')
            proc=subprocess.Popen([sys.executable,'-m','brain.server','--port',str(port),'--logs',tmp],
                cwd=ROOT,env={**os.environ,'FLYFEAR_TOKEN':token},stdout=output,stderr=output)
            async def receive(ws,kind):
                for _ in range(20):
                    msg=json.loads(await asyncio.wait_for(ws.recv(),5))
                    if msg.get('type')==kind:return msg
                self.fail(f'Missing message {kind}')
            try:
                uri=f'ws://127.0.0.1:{port}/{token}'
                for _ in range(60):
                    try:
                        ws=await connect(uri,proxy=None);break
                    except OSError:await asyncio.sleep(.1)
                else:self.fail('Worker failed to start')
                async with ws:
                    hello=await receive(ws,'hello');self.assertEqual(hello['info']['neurons'],166700)
                    with self.assertRaises(InvalidStatus):
                        await connect(uri,origin='https://example.com',proxy=None)
                    async with connect(f'ws://127.0.0.1:{port}/wrong-token',proxy=None) as bad:
                        with self.assertRaises(ConnectionClosed): await bad.recv()
                    await ws.send('{"type":"decision","id":1,"telemetry":{"x":"bad"}}')
                    self.assertEqual((await receive(ws,'error'))['action'],'wait')
                    # Seed 3 selects a nonwait action first for a measurable reward test.
                    await ws.send(json.dumps({'type':'start','mode':'learn','seed':3,'interval':2}))
                    await receive(ws,'started');await asyncio.sleep(2)
                    t={'x':1,'z':0,'look_x':0,'look_z':-1,'speed':3.2,'retreat':0,'turn_rate':0,'pause_seconds':0}
                    await ws.send(json.dumps({'type':'decision','id':2,'telemetry':t}))
                    result=await receive(ws,'decision')
                    self.assertEqual(result['id'],2);self.assertGreater(result['neural']['active_neurons'],0)
                    self.assertNotEqual(result['action'],'wait')
                    await ws.send(json.dumps({'type':'applied','id':2,'accepted':True,'telemetry':t}))
                    t.update(speed=0,retreat=3.2,turn_rate=180)
                    for _ in range(23):
                        await ws.send(json.dumps({'type':'telemetry','telemetry':t}));await asyncio.sleep(.1)
                    reward=await receive(ws,'reward');self.assertEqual(reward['updates'],1);self.assertEqual(reward['reward'],1)
                    # Duplicate ACK cannot train twice.
                    await ws.send(json.dumps({'type':'applied','id':2,'accepted':True,'telemetry':t}))
                    await ws.send('{"type":"save"}')
                    self.assertEqual((await receive(ws,'parameters'))['updates'],1)
                    self.assertTrue((Path(tmp)/'learning.json').exists())
                    await ws.send('{"type":"reset"}')
                    self.assertEqual((await receive(ws,'parameters'))['updates'],0)
                    await ws.send('{"type":"pause"}')
                    await ws.send(json.dumps({'type':'decision','id':3,'telemetry':t}))
                    with self.assertRaises(asyncio.TimeoutError):await asyncio.wait_for(ws.recv(),.25)
                await asyncio.sleep(.15)
                async with connect(uri,proxy=None) as ws2:
                    self.assertEqual((await receive(ws2,'hello'))['protocol'],1)
                    proc.terminate();await asyncio.to_thread(proc.wait,5)
                    with self.assertRaises(ConnectionClosed):await ws2.recv()
                lines=[json.loads(s) for f in Path(tmp).glob('*.jsonl') for s in f.read_text().splitlines()]
                self.assertTrue(any(x['type']=='decision' and 'neural' in x and 'inputs' in x for x in lines))
                self.assertEqual(sum(x['type']=='reward' for x in lines),1)
            finally:
                if proc.poll() is None:proc.terminate();proc.wait(timeout=5)
                output.close()

if __name__=='__main__':unittest.main(verbosity=2)
