#!/bin/zsh
set -eu
cd "${0:A:h}"
.venv/bin/python -m unittest discover -s tests -v
./run.sh --headless --smoke
print 'Python ve headless oynanış testleri geçti. Görünür 1080p ölçüm: ./run.sh --benchmark'
